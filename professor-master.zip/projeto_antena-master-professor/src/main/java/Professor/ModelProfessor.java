package Professor;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import org.bson.Document;
import org.bson.conversions.Bson;

import com.github.fakemongo.Fongo;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.FindOneAndUpdateOptions;

public class ModelProfessor {

	Fongo fongo = new Fongo("app");

	public String search(String chave, String valor) {
		MongoDatabase db = fongo.getDatabase("app");
		MongoCollection<Document> projects = db.getCollection("projeto");
		FindIterable<Document> found = projects.find(new Document(chave, valor));
		String foundJson = StreamSupport.stream(found.spliterator(), false).map(Document::toJson)
				.collect(Collectors.joining(", ", "[", "]"));
		// System.out.println(foundJson);
		return foundJson;
	}
	public String searchUsuario(String chave, String valor) {
		MongoDatabase db = fongo.getDatabase("app");
		MongoCollection<Document> projects = db.getCollection("professor");
		FindIterable<Document> found = projects.find(new Document(chave, valor));
		String foundJson = StreamSupport.stream(found.spliterator(), false).map(Document::toJson)
				.collect(Collectors.joining(", ", "[", "]"));
		// System.out.println(foundJson);
		return foundJson;
	}
	public FindIterable<Document> buscaPorDono(String email) {
		MongoDatabase db = fongo.getDatabase("app");
		MongoCollection<Document> projetos = db.getCollection("projeto");
		FindIterable<Document> found = projetos.find(new Document("responsavel-professor", email));

		return found;
	}
	public String buscaSemDono() {
		MongoDatabase db = fongo.getDatabase("app");
		MongoCollection<Document> projects = db.getCollection("projeto");
		FindIterable<Document> found = projects.find(new Document("responsavel-professor", ""));
		String foundJson = StreamSupport.stream(found.spliterator(), false).map(Document::toJson)
				.collect(Collectors.joining(", ", "[", "]"));
		// System.out.println(foundJson);
		return foundJson;
	}
	


	public void addProfessor(Document doc) {
		MongoDatabase db = fongo.getDatabase("app");
		MongoCollection<Document> researches = db.getCollection("professor");
		researches.insertOne(doc);
	}

	public void addProjeto(Document doc) {
		MongoDatabase db = fongo.getDatabase("app");
		MongoCollection<Document> projeto = db.getCollection("projeto");
		projeto.insertOne(doc);
	}
	
	//teste
	
	public Document login(String email, String senha) {
		MongoDatabase db = fongo.getDatabase("app");
		MongoCollection<Document> professor = db.getCollection("professor");
		Document found = professor.find(new Document("email", email).append("senha", senha)).first();
		return found;
	}
	
	public Document ativarProfessor(String email) {
		MongoDatabase db = fongo.getDatabase("app");
		MongoCollection<Document> professores = db.getCollection("professor");
		Document professor = searchByEmail(email);
		System.out.println(email);
		System.out.println(professor);
		professores.deleteOne(professor);
		professor.replace("ativo", true);
		
		
		
		BasicDBObject query = new BasicDBObject();
		query.append("id", professor.get("id"));
		professores.replaceOne(query, professor);
		//cadis.findOneAndUpdate(query, cadi, (new FindOneAndUpdateOptions()).upsert(true));
		return professor;
	}

	
	public Document searchByEmail(String email) {
		MongoDatabase db = fongo.getDatabase("app");
		MongoCollection<Document> professor = db.getCollection("professor");
		Document found = professor.find(new Document("email", email)).first();
		return found;

	}

	public FindIterable<Document> listaProjetos() {
		MongoDatabase db = fongo.getDatabase("app");
		MongoCollection<Document> projetos = db.getCollection("projeto");
		FindIterable<Document> found = projetos.find();
		return found;
	}

	
	public List<String> listProfessor() {
		MongoDatabase db = fongo.getDatabase("app");
		MongoCollection<Document> professorF = db.getCollection("professor");
		FindIterable<Document> professor = professorF.find();
		List<String> listProfessor = new ArrayList<String>();
		for(Document proj:professor) {
			listProfessor.add(proj.toJson());
		}
		return listProfessor;
	}
	
	//test profs
	public FindIterable<Document> listProf() {
		MongoDatabase db = fongo.getDatabase("app");
		MongoCollection<Document> prof = db.getCollection("professor");
		FindIterable<Document> found = prof.find();
		return found;
	}

	public void alterarId (String id, Document alteracao){
		Document filter = new Document("id", id);
		MongoDatabase db = fongo.getDatabase("app");
		MongoCollection<Document> professorF = db.getCollection("professor");
		professorF.updateOne(filter, alteracao);
		}
	
	public void addReuniao(Document doc) {
		MongoDatabase db = fongo.getDatabase("app");
		MongoCollection<Document> reuniao = db.getCollection("reuniao");
		reuniao.insertOne(doc);

	}
	
	
	/*Update*/
	public Document updateProjeto(Document projeto) {
		MongoDatabase db = fongo.getDatabase("app");
		MongoCollection<Document> projetos = db.getCollection("projeto");
		BasicDBObject query = new BasicDBObject();
		query.append("_id", projeto.get("_id"));
		Bson newDocument = new Document("$set", projeto);
		return projetos.findOneAndUpdate(query, newDocument, (new FindOneAndUpdateOptions()).upsert(true));
	}
	
	
	public Document updateProfessor(Document projeto) {
		MongoDatabase db = fongo.getDatabase("app");
		MongoCollection<Document> projetos = db.getCollection("professor");
		BasicDBObject query = new BasicDBObject();
		query.append("_id", projeto.get("_id"));
		Bson newDocument = new Document("$set", projeto);
		return projetos.findOneAndUpdate(query, newDocument, (new FindOneAndUpdateOptions()).upsert(true));
	}
	
	

}
